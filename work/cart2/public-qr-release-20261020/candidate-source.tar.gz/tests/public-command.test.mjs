import test from "node:test";
import assert from "node:assert/strict";
import { planGuestCommand, requiresOwnerAuthorization, runGuestCommand } from "../candidate/edge/guest-command.ts";

const commandId = "a48bce39-5f73-4efc-9bd6-bb8f839e1c3d";
const fixture = (revision = 7) => ({
  desired: { revision, state: { guestMode: false, devices: { matrix: { brightness: 46 }, aux: { brightness: 255 } } } },
  fence: { epoch: 5, release_id: "hbnf-cart-foundation-v1", active: true },
});
const request = (overrides = {}) => ({ commandId, expectedRevision: 7, guestAction: "vibe", value: "chill", ...overrides });

function deps({ limit = { allowed: true, retry_after_seconds: 0 }, context = fixture(), limitError = null } = {}) {
  const calls = { limited: 0, committed: 0, reconciled: 0 };
  return {
    calls,
    readContext: async () => ({ data: context, error: null }),
    consumePublicRateLimit: async () => { calls.limited++; return { data: limit, error: limitError }; },
    commit: async () => { calls.committed++; return { data: { result_revision: 8, duplicate: false }, error: null }; },
    reconcile: async () => { calls.reconciled++; return { ok: true, status: 200, body: { status: "queued" } }; },
  };
}

test("public Vibe command is available without Guest Mode and remains revision-bound", () => {
  const plan = planGuestCommand(request(), fixture().desired.state, 7);
  assert.equal(plan.ok, true);
  assert.equal(plan.type, "VIBE");
  assert.equal(plan.expectedRevision, 7);
  assert.equal(plan.payload.vibe, "chill");
});

test("public brightness writes only the selected device", () => {
  const matrix = planGuestCommand(request({ guestAction: "matrix_brightness", value: "53" }), fixture().desired.state, 7);
  const aux = planGuestCommand(request({ guestAction: "aux_brightness", value: "116" }), fixture().desired.state, 7);
  assert.deepEqual(matrix.payload, { matrixBrightness: 53 });
  assert.deepEqual(aux.payload, { auxBrightness: 116 });
});

test("privileged actions stay on the owner-authorized route", () => {
  assert.equal(requiresOwnerAuthorization("command", "FIRMWARE_UPDATE"), true);
  assert.equal(requiresOwnerAuthorization("pair_device", undefined), true);
  assert.equal(requiresOwnerAuthorization("create_install_handoff", undefined), true);
  assert.equal(planGuestCommand(request({ guestAction: "firmware_update", value: "" }), fixture().desired.state, 7).ok, false);
});

test("owner revision advance rejects a stale public command before consuming capacity", async () => {
  const d = deps({ context: fixture(8) });
  const result = await runGuestCommand(request(), d);
  assert.equal(result.status, 409);
  assert.equal(result.body.error, "stale_revision");
  assert.equal(d.calls.limited, 0);
  assert.equal(d.calls.committed, 0);
});

test("rate-limited public command returns bounded retry guidance and does not commit", async () => {
  const d = deps({ limit: { allowed: false, retry_after_seconds: 4 } });
  const result = await runGuestCommand(request(), d);
  assert.equal(result.status, 429);
  assert.deepEqual(result.body, { error: "public_rate_limit_exceeded", retryAfterSeconds: 4 });
  assert.equal(d.calls.limited, 1);
  assert.equal(d.calls.committed, 0);
  assert.equal(d.calls.reconciled, 0);
});

test("limiter failure fails closed without commit or device reconciliation", async () => {
  const d = deps({ limit: null, limitError: { message: "database unavailable" } });
  const result = await runGuestCommand(request(), d);
  assert.equal(result.status, 503);
  assert.equal(result.body.error, "public_rate_limit_unavailable");
  assert.equal(d.calls.committed, 0);
  assert.equal(d.calls.reconciled, 0);
});

test("accepted public command consumes one token then commits and reconciles", async () => {
  const d = deps();
  const result = await runGuestCommand(request(), d);
  assert.equal(result.status, 202);
  assert.equal(d.calls.limited, 1);
  assert.equal(d.calls.committed, 1);
  assert.equal(d.calls.reconciled, 1);
});
