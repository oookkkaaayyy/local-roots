import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";

const client = readFileSync(new URL("../candidate/public/guest.js", import.meta.url), "utf8");
const response = (body, status = 200, headers = {}) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json", ...headers } });

function makeClient() {
  const nodes = new Map();
  const make = (id, props = {}) => {
    const listeners = {};
    const node = {
      id, tagName: "DIV", value: "", textContent: "", className: "", hidden: false, disabled: false,
      attributes: {}, listeners, options: [], hasAttribute(name) { return Object.hasOwn(this.attributes, name); },
      getAttribute(name) { return this.attributes[name] ?? null; }, setAttribute(name, value) { this.attributes[name] = String(value); },
      addEventListener(name, callback) { (listeners[name] ||= []).push(callback); },
      ...props,
    };
    nodes.set(id, node);
    return node;
  };
  const vibe = make("vibe-chill", { tagName: "BUTTON", attributes: { "data-guest-action": "vibe", "data-value": "chill", "data-vibe-control": "" } });
  const matrix = make("matrixBrightness", { tagName: "INPUT", value: "53", attributes: { "data-guest-action": "matrix_brightness" } });
  const controls = [vibe, matrix];
  for (const id of ["primaryStatus", "secondaryStatus", "live", "deviceStatus", "connectionBadge", "guestBadge", "vibeOptions", "vibeAvailability", "guestAutoVibe", "matrixBrightnessValue", "auxBrightnessValue", "guestMotionValue", "guestAudioValue", "guestScene", "guestPalette", "guestText", "retry"]) {
    if (!nodes.has(id)) make(id, id === "guestPalette" ? { options: [{ value: "hbnf-balanced" }] } : {});
  }
  const query = (selector) => selector === "[data-guest-action],[data-guest-input]" ? controls : selector === "button[data-guest-action]" ? [vibe] : selector === '[data-guest-action="vibe"]' ? [vibe] : [];
  const document = { querySelectorAll: query, getElementById: (id) => nodes.get(id) || make(id) };
  const windowListeners = {};
  const window = {
    location: { pathname: "/guest/hbnf-cart/" },
    crypto: { getRandomValues(bytes) { bytes.fill(0); } },
    addEventListener(name, callback) { (windowListeners[name] ||= []).push(callback); },
    setInterval() { return 1; },
  };
  let commandResolver;
  let revision = 7;
  const requests = [];
  const fetch = (_url, options) => {
    const body = JSON.parse(options.body);
    requests.push({ body, options });
    if (body.action === "status") {
      return Promise.resolve(response({
        desired: { revision, state: { guestMode: false, selectedVibe: "chill", devices: { matrix: { brightness: 46 }, aux: { brightness: 255 } }, tuning: { motion: 50, audioResponse: 50 } } },
        capabilities: { phase2VibeRuntimeV1: true, autoVibeControlV1: false },
        observed: [],
      }));
    }
    return new Promise((resolve) => { commandResolver = resolve; });
  };
  vm.runInNewContext(client, { window, document, fetch, Response, URL, Date, Promise, Math, Number, String, Array, JSON, Error, Uint8Array });
  return { nodes, vibe, matrix, controls, requests, windowListeners, resolveCommand(value) { commandResolver(value); }, setRevision(value) { revision = value; } };
}

const flush = () => new Promise((resolve) => setImmediate(resolve));

test("controls enable without a Guest Mode flag and tap gives immediate pending feedback", async () => {
  const app = makeClient();
  await flush();
  assert.equal(app.vibe.disabled, false);
  app.vibe.listeners.click[0]();
  assert.equal(app.nodes.get("primaryStatus").textContent, "Sending your choice…");
  assert.equal(app.requests.filter((r) => r.body.action === "guest_command").length, 1);
  const command = app.requests.find((r) => r.body.action === "guest_command");
  assert.equal(command.body.guestAction, "vibe");
  assert.equal(command.options.credentials, "omit");
  assert.equal(command.options.headers.Authorization, undefined);
  app.resolveCommand(response({ revision: 8, reconciliation: { status: "queued" } }, 202));
  app.setRevision(8);
  await flush();
  assert.match(app.nodes.get("primaryStatus").textContent, /Waiting for the Cart/);
});

test("brightness slider sends once on change, not while dragging", async () => {
  const app = makeClient();
  await flush();
  app.matrix.value = "53";
  app.matrix.listeners.input[0]();
  assert.equal(app.requests.filter((r) => r.body.action === "guest_command").length, 0);
  app.matrix.listeners.change[0]();
  assert.equal(app.requests.filter((r) => r.body.action === "guest_command").length, 1);
  assert.deepEqual(JSON.parse(JSON.stringify(app.requests.find((r) => r.body.action === "guest_command").body)), {
    action: "guest_command", commandId: "00000000-0000-4000-8000-000000000000", expectedRevision: 7,
    guestAction: "matrix_brightness", value: "53",
  });
});

test("429 presents Retry-After and does not auto-retry", async () => {
  const app = makeClient();
  await flush();
  app.vibe.listeners.click[0]();
  app.resolveCommand(response({ error: "public_rate_limit_exceeded", retryAfterSeconds: 5 }, 429, { "Retry-After": "5" }));
  await flush();
  assert.equal(app.nodes.get("primaryStatus").textContent, "Please wait before sending another choice.");
  assert.match(app.nodes.get("secondaryStatus").textContent, /5 seconds/);
  assert.equal(app.vibe.disabled, false);
  assert.equal(app.requests.filter((r) => r.body.action === "guest_command").length, 1);
});
