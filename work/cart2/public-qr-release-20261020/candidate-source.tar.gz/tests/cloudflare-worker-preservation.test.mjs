import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import { createHash } from "node:crypto";

const root = new URL("../", import.meta.url);
const base = await readFile(new URL("baseline/cloudflare-worker/worker.js", root), "utf8");
const candidate = await readFile(new URL("candidate/cloudflare/worker.js", root), "utf8");
const changedRoutes = new Set([
  "/guest/hbnf-cart/",
  "/guest/hbnf-cart/guest.js",
  "/guest/hbnf-cart/guest.webmanifest",
]);

function table(source) {
  const marker = "var FILES = ";
  const markerStart = source.indexOf(marker);
  assert.notEqual(markerStart, -1);
  const start = markerStart + marker.length;
  let depth = 0;
  let inString = false;
  let escaped = false;
  let end = -1;
  for (let i = start; i < source.length; i += 1) {
    const char = source[i];
    if (inString) {
      if (escaped) escaped = false;
      else if (char === "\\\\") escaped = true;
      else if (char === '"') inString = false;
      continue;
    }
    if (char === '"') inString = true;
    else if (char === "{") depth += 1;
    else if (char === "}") {
      depth -= 1;
      if (depth === 0) {
        end = i + 1;
        break;
      }
    }
  }
  assert.notEqual(end, -1);
  const parsed = JSON.parse(source.slice(start, end));
  return { parsed, prefix: source.slice(0, start), suffix: source.slice(end) };
}

test("Cart Worker candidate changes only the public control HTML, JS, and manifest", async () => {
  const original = table(base);
  const updated = table(candidate);
  assert.deepEqual(Object.keys(updated.parsed).sort(), Object.keys(original.parsed).sort());
  assert.equal(updated.prefix, original.prefix);
  assert.equal(updated.suffix, original.suffix.replace("//# sourceMappingURL=worker.js.map\n", ""));
  const actualChanged = Object.keys(original.parsed).filter((route) =>
    JSON.stringify(original.parsed[route]) !== JSON.stringify(updated.parsed[route])
  );
  assert.deepEqual(new Set(actualChanged), changedRoutes);
  for (const route of Object.keys(original.parsed)) {
    if (!changedRoutes.has(route)) assert.deepEqual(updated.parsed[route], original.parsed[route], route);
    const entry = updated.parsed[route];
    const bytes = Buffer.from(entry.b64, "base64");
    assert.equal(bytes.length, entry.size, route + " size");
    assert.equal(createHash("sha256").update(bytes).digest("hex"), entry.sha256, route + " sha256");
    assert.equal(entry.etag, '"sha256-' + entry.sha256 + '"', route + " etag");
  }
});

test("Owner assets, ASSETS binding, runtime and Worker routing code stay byte-identical", () => {
  const original = table(base);
  const updated = table(candidate);
  for (const [route, entry] of Object.entries(original.parsed)) {
    if (route.startsWith("/guest/hbnf-cart/")) continue;
    assert.deepEqual(updated.parsed[route], entry, route);
  }
  assert.match(updated.suffix, /env\.ASSETS\.fetch\(request\)/);
  assert.match(updated.suffix, /Method Not Allowed/);
});

test("public control uses friendly app text and never presents the retired toggle", async () => {
  const html = await readFile(new URL("candidate/public/index.html", root), "utf8");
  const js = await readFile(new URL("candidate/public/guest.js", root), "utf8");
  assert.match(html, /<title>HBNF Cart Control<\/title>/);
  assert.doesNotMatch(html, /Guest Mode|Checking Guest Mode|Turn Guest Mode/i);
  assert.doesNotMatch(js, /Guest Mode|guest_mode_closed/i);
});
