#!/usr/bin/env python3
"""Re-embed only the approved public Cart assets into the exact active Worker."""
from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "baseline/cloudflare-worker/worker.js"
PUBLIC = ROOT / "candidate/public"
OUTPUT = ROOT / "candidate/cloudflare/worker.js"
MARKER = "var FILES = "
REPLACEMENTS = {
    "/guest/hbnf-cart/": "index.html",
    "/guest/hbnf-cart/guest.js": "guest.js",
    "/guest/hbnf-cart/guest.webmanifest": "guest.webmanifest",
}
UNCHANGED_PUBLIC = {
    "/guest/hbnf-cart/guest.css": "guest.css",
    "/guest/hbnf-cart/hbnf-cart-icon-180.png": "hbnf-cart-icon-180.png",
}
INDEX_SOURCE = ROOT / "baseline/cloudflare-embedded-assets/guest/hbnf-cart/index.html"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_embedded(source: str) -> tuple[dict, int, int]:
    marker_at = source.index(MARKER)
    start = marker_at + len(MARKER)
    table, used = json.JSONDecoder().raw_decode(source[start:])
    return table, start, start + used


source = BASELINE.read_text()
assets, files_start, files_end = load_embedded(source)

# Start from the exact active Worker HTML, then apply only public-control copy
# and cache-version changes. This avoids repackaging an edge-injected response.
html = INDEX_SOURCE.read_text()
html_replacements = {
    'content="HBNF Guest"': 'content="HBNF Cart"',
    "<title>HBNF Cart Guest</title>": "<title>HBNF Cart Control</title>",
    'href="./guest.webmanifest?v=20261017-guest-pwa-v1"':
        'href="./guest.webmanifest?v=20261020-public-control-v1"',
    "<div><h1>Choose a Vibe</h1></div>": "<div><h1>Cart Controls</h1></div>",
    '<strong id="primaryStatus">Checking Guest Mode…</strong>':
        '<strong id="primaryStatus">Connecting to the Cart…</strong>',
    '<span id="guestBadge" class="badge closed">CLOSED</span>':
        '<span id="guestBadge" class="badge closed">CONNECTING</span>',
    'href="./guest.css?v=20261016-compact-ui-v1"':
        'href="./guest.css?v=20261020-public-control-v1"',
    'src="./guest.js?v=20261016-compact-ui-v1"':
        'src="./guest.js?v=20261020-public-control-v1"',
}
for old, new in html_replacements.items():
    if html.count(old) != 1:
        raise SystemExit("active HTML no longer matches the expected source fragment: " + old)
    html = html.replace(old, new, 1)
(PUBLIC / "index.html").write_text(html)

# Validate the recovered provider bytes before using them as the candidate base.
for route, asset in assets.items():
    content = base64.b64decode(asset["b64"], validate=True)
    if len(content) != asset["size"] or sha(content) != asset["sha256"]:
        raise SystemExit("active Worker embedded asset failed its declared hash: " + route)

for route, filename in UNCHANGED_PUBLIC.items():
    candidate = (PUBLIC / filename).read_bytes()
    original = base64.b64decode(assets[route]["b64"], validate=True)
    if candidate != original:
        raise SystemExit("unexpected change to unchanged public asset: " + filename)

for route, filename in REPLACEMENTS.items():
    content = (PUBLIC / filename).read_bytes()
    entry = assets[route]
    entry["b64"] = base64.b64encode(content).decode("ascii")
    entry["sha256"] = sha(content)
    entry["size"] = len(content)
    entry["etag"] = '"sha256-' + entry["sha256"] + '"'

replacement = json.dumps(assets, separators=(",", ":"), ensure_ascii=True)
OUTPUT.parent.mkdir(parents=True, exist_ok=True)
candidate_source = source[:files_start] + replacement + source[files_end:]
# The source map describes the old, differently sized asset table. Preserve
# that exact map beside the baseline and omit its now-stale reference here.
source_map_reference = "//# sourceMappingURL=worker.js.map\n"
if candidate_source.count(source_map_reference) != 1 or not candidate_source.endswith(source_map_reference):
    raise SystemExit("active Worker source-map marker changed; review before packaging")
candidate_source = candidate_source[:-len(source_map_reference)]
OUTPUT.write_text(candidate_source)

candidate, _, _ = load_embedded(OUTPUT.read_text())
if set(candidate) != set(assets):
    raise SystemExit("candidate changed the active Worker asset route inventory")
for route in candidate:
    expected_hash = assets[route]["sha256"]
    payload = base64.b64decode(candidate[route]["b64"], validate=True)
    if len(payload) != candidate[route]["size"] or sha(payload) != expected_hash:
        raise SystemExit("candidate asset failed hash verification: " + route)

print("candidate_worker_sha256=" + sha(OUTPUT.read_bytes()))
print("preserved_route_count=" + str(len(candidate)))
print("changed_routes=" + ",".join(REPLACEMENTS))
