-- One global public-command token bucket for the bounded Cart QR reducer.
-- Owner commands use the existing paired/owner route and do not call this RPC.
-- Pairing handoffs remain available only through the Owner-authorized Edge
-- route; do not allow direct public RPC calls to mint pairing tokens.
revoke all on function public.hbnf_cart_create_install_handoff(text, text, timestamptz)
  from public, anon, authenticated;
grant execute on function public.hbnf_cart_create_install_handoff(text, text, timestamptz)
  to service_role;

create table if not exists hbnf_internal.cart_public_command_rate_limit (
  singleton_id boolean primary key default true check (singleton_id = true),
  tokens numeric(12, 6) not null check (tokens >= 0 and tokens <= 12),
  updated_at timestamptz not null
);

alter table hbnf_internal.cart_public_command_rate_limit enable row level security;
revoke all on table hbnf_internal.cart_public_command_rate_limit from public, anon, authenticated;
grant select, update on table hbnf_internal.cart_public_command_rate_limit to service_role;

insert into hbnf_internal.cart_public_command_rate_limit(singleton_id, tokens, updated_at)
values (true, 12, pg_catalog.clock_timestamp())
on conflict (singleton_id) do nothing;

create or replace function public.hbnf_cart_consume_public_command_token()
returns table(allowed boolean, retry_after_seconds integer)
language plpgsql
security invoker
set search_path = pg_catalog
as $function$
declare
  v_bucket hbnf_internal.cart_public_command_rate_limit%rowtype;
  v_now timestamptz;
  v_elapsed numeric;
  v_available numeric;
  v_remaining numeric;
begin
  select * into v_bucket
    from hbnf_internal.cart_public_command_rate_limit
    where singleton_id = true
    for update;

  if not found then
    return query select false, 1;
    return;
  end if;

  -- Read time only after acquiring the serialized bucket row. A transaction
  -- that waited behind another consumer must not write an older timestamp.
  v_now := pg_catalog.clock_timestamp();
  v_elapsed := greatest(0::numeric, extract(epoch from (v_now - v_bucket.updated_at))::numeric);
  v_available := least(12::numeric, v_bucket.tokens + v_elapsed);

  if v_available >= 1 then
    v_remaining := v_available - 1;
    update hbnf_internal.cart_public_command_rate_limit
      set tokens = v_remaining, updated_at = v_now
      where singleton_id = true;
    return query select true, 0;
  else
    update hbnf_internal.cart_public_command_rate_limit
      set tokens = v_available, updated_at = v_now
      where singleton_id = true;
    return query select false, greatest(1, ceil(1 - v_available)::integer);
  end if;
end;
$function$;

revoke all on function public.hbnf_cart_consume_public_command_token() from public, anon, authenticated;
grant execute on function public.hbnf_cart_consume_public_command_token() to service_role;
