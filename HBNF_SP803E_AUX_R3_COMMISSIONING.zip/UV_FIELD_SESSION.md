# HBNF Cart UV integration — current handoff (2026-10-26)

## Current status

- **Physical integration review: PASS**, as owner-confirmed from the dedicated UV physical-integration coordinator. Do not reopen that review, repeat hardware research, or ask the owner to locate or resend its report.
- The removable module is assembled and staged off-Cart. It remains disconnected from AUX and unpowered; no working Cart hardware was changed. The owner reports the unpowered meter checks are complete but supplied no numerical readings or receipt. Powered output, channel current, temperature, live PWM behavior, combined-load operation, and device acceptance remain for one combined field session.
- **Installed AUX baseline: V7, owner-confirmed current.** The owner confirms V7 was installed and nothing has been installed since. The exact retained V7 image is `HBNF_SP803E_AUX_V7_ROLLBACK.bin`, SHA-256 `c44298bb4b80a0e3d36d094f8270a1959708997571784803592e257ecdef054a`, source `e78fc74c9470b0bafaf43ca6a2823f60f1a4b51e`, Actions run `40276725561`. Do not reopen baseline recovery.
- RIM/Cart is intended for PWM3/GPIO25 and SHORT/Bar for PWM2/GPIO26. The reported parts are a TOBSUN EA50-5V converter, two USB-A female adapters, shared fused 5V positive with inline 5A fuse, lever connectors, and a three-port ground junction with AUX ground reserved. These remain owner-reported connection details; the strips are not attached to AUX.

## Software already prepared

- **Earlier fail-dark build disposition (2026-10-26): do not install run 40373345832.** Its commissioning ZIP was built and verified from source `13214924cf62d2056ce54d0f7467c71bd85ea155`; ZIP SHA-256 `ef3a5b9ff471f67571ef0ea72c0514d06e65998b81a63c2c1879321875cd5e02`. The packaged `HBNF_SP803E_AUX_R3.bin` is 1,348,624 bytes and hashes to `c44298bb4b80a0e3d36d094f8270a1959708997571784803592e257ecdef054a`, byte-for-byte matching the retained V7 rollback image. The run passed compile/reproducibility/package checks, but this output is a duplicate of V7, has `UV_OUTPUTS_VERIFIED=NO`, and is marked `REVIEW_ONLY`; it adds no new firmware behavior. The verified ZIP is preserved on branch `hbnf-aux-r3-artifact-run-40373345832-attempt-1`. Do not mistake a green package workflow for a new or installable UV release.
- **Previous output-capable package (run 40399701154):** source `4c0962628237b4c6c355d313ab9683414eba9961`; commissioning ZIP SHA-256 `9dd7fb0aeee7506ffe115e5c0f1558b7830aded86f7737152c9d35ef2e8d83e4`; firmware SHA-256 `94afbf7af2dd672952e95978841cf28ff49bb10c6d209fd852fe651c66f7ab29`. Superseded as a release candidate by the current source-bound package recorded below; retain its private run branch as historical evidence.
- Runs 40397846722 and 40398933774 are older package snapshots of the same firmware image SHA `94afbf7af2dd672952e95978841cf28ff49bb10c6d209fd852fe651c66f7ab29`; they are not distinct firmware candidates and are superseded by run 40399701154 as the retained complete package. Run 40396790656 predates the PWM minimum-level correction and must not be installed.

- UV firmware source commit `23c1d37f3db0d03421312ab986f61f92c3abe11d` adds local Matrix audio following. Fresh audio scales each strip by its own selected cap; stale audio falls back to that cap; zero cap and the firmware output gate remain dark. The local UV-enabled firmware is `HBNF_SP803E_AUX_R3_UV_ENABLED_STALE_AUDIO_FALLBACK_23c1d37_REVIEW_ONLY.bin`, SHA-256 `a4bdbd4f1e8f11e59c40627e7b291f230b2b1e112ebf144dc03a9585a6758d43`. Its clean build reproduced byte-for-byte; it has not been installed.
- The source correction used in run 40397846722 floors fresh zero-energy audio to PWM level 1 when the selected cap is nonzero. Zero cap and the output safety gate still return dark; stale audio still uses the selected cap. Focused host assertions and exact-source CI passed. This guarantees a nonzero PWM command only; visible illumination at that level remains a powered field observation.
- Opal/PWA source commit `a7f8fcb399d07bf0757d966ca940ce3dc02a9b0c` adds a shared main-page UV slider, independent Cart and Bar fine-tuning, explicit Apply manual override / Follow Matrix / UV off actions, and an authenticated local UV route. Opening the page sends no UV command.
- The Opal route's readiness-policy gap is closed in source commit `d0c86f623b7346f5ed376c9e2912136ea8a28bb9`: it shares the AUX hardware profile and checks the same runtime and commissioning gates before any WLED write. The candidate profile is default-off, records owner-reported assembly details separately, and leaves operational measurements/gates unverified.
- **Owner PWA v1.0.14 package is built and staged.** It is based on the exact v1.0.13 rollback (`60509839edb902f25546878094d0b39f7d8ce78ca54e99d23e66d84deb41155a`, 1,323,693 bytes), includes the source-bound read-only live preflight, and has package SHA-256 `6c393c5dde6dc78ea16823922c0c2717ccc4ae88dd5fa9e4047efb2e71044a17`. Its installer verifies the existing 21-file tree and retains that exact tree before swapping. An isolated temporary-tree install/rollback simulation passed: all 21 candidate files installed, the exact v1.0.13 baseline was retained and verified, and rollback restored and verified v1.0.13. This is rehearsal evidence only; no Cart mutation occurred. Historical evidence reports 17/17 served v1.0.13 assets matched the saved manifest; the installer's fresh preflight still must verify the actual live filesystem.

- **Latest Owner Local Control package:** exact source, version, ZIP hash, and accepted exposure record are recorded below after build. The prior v1.0.10 package and its source record remain retained; no device or network changes have been applied.

### Opal package gates when the device is available

- **Owner PWA v1.0.14:** package SHA-256 `6c393c5dde6dc78ea16823922c0c2717ccc4ae88dd5fa9e4047efb2e71044a17`; exact v1.0.13 rollback package SHA-256 `60509839edb902f25546878094d0b39f7d8ce78ca54e99d23e66d84deb41155a`. Offline archive checks, payload hashes, all 25 source-input hashes, and installer shell syntax pass. This remains `INSTALLABLE_REQUIRES_EXISTING_ADMISSION`: historical HTTP readback covered only 17 served files, while the fresh installer preflight must verify the actual 21-file installed tree and create/read back its transaction rollback. On Cart, first inspect current identity/version and run the package's read-only checks; proceed with `sh ./install.sh` from the extracted v1.0.14 package directory only if existing admission is valid and every preflight check passes. Require the installer's success line naming v1.0.14 and the exact retained v1.0.13 snapshot, then verify all payload hashes and runtime version. Any mismatch means stop without replacing the installed directory.
- Gateway v1.0.12 keeps the exact Mission Control rollback hash and requires a fresh live hash match; the owner-accepted network exposure is source-recorded and unpaired-client isolation is neither tested nor required.
- **Current disposition:** neither package is install-admissible without a fresh Cart identity/baseline read and existing release admission. No installation or device/network change has been made.

### Staged install order

1. Owner PWA v1.0.14, only after its exact live 21-file baseline and v1.0.13 rollback pass admission and install-time verification.
2. Owner Local Control v1.0.12, only after its fresh transport hash, TLS/DNS, Matrix/AUX, and existing release admission pass. The source-bound owner acceptance records direct WLED exposure; no denial probe is claimed or required.
3. The new exact-source AUX output-capable Actions package, only after its fresh V7 target identity/preflight, exact rollback, one-attempt control, and receipt requirements pass. Powered UV output/physical tests remain separate acceptance gates; the accepted network exposure does not open UV activation.
- The current Git branch also contains the exact live Supabase function v35 source and exact v34 rollback source under `evidence/live-production-20261026/`. The v35 function source hash is `377945d8c9c930420ac36febd304d2a4d5f632cbcc4c9e3467c8f440aaa04e73`.
- Focused UV UI/route checks passed 3/3, deterministic package checks passed 2/2, shell syntax and diff checks passed. These establish source/package properties only, not live Opal, network-isolation, or device acceptance.

## Remaining release gates

The source-level parity gap is closed. The owner-confirmed physical integration review is PASS; do not repeat it. The pairing-expiry contract is now live: migration `20261026160033_hbnf_cart_device_session_expiry` and Cart control v35 return the authoritative stored expiry after device-session validation. The exact v34 rollback source and v35 live source are retained under `evidence/live-production-20261026/`. Certificate/split-DNS setup and the live gateway/network checks remain separate field/setup items; the hardware profile intentionally remains default-off until powered channel acceptance.

The owner explicitly accepts that unpaired clients on shared Cart Wi-Fi may access Matrix/AUX WLED JSON APIs without authentication. Raw API calls can bypass Owner/Guest PWA visibility and command constraints and may set supported device states/effects. Gateway authentication applies only to gateway HTTPS endpoints. This exposure is encoded as `OWNER_ACCEPTED_EXPOSURE`; its observation status is `NOT_TESTED`, and no denial probe is required for release admission. This does not alter exact V7 rollback or powered UV gates.

## One combined field acceptance session

### UV output-capable firmware admission

The UV-enabled build uses the normal exact-source commissioning distribution and carries the exact V7 rollback, source/run receipt, and package checksums. Its compile-time output capability is distinct from activation: the backend UV profile and all commissioning gates remain default-off; Opal's local route requires the verified hardware profile plus every required runtime/commissioning gate. The firmware reports `uvBuildProfile=uv-follow-output-capable-v1`, so the operator can distinguish the output-capable candidate from the retained fail-dark V7 baseline and verify the post-install runtime mode.

The owner accepts that unpaired Cart-Wi-Fi clients can reach the unauthenticated WLED API. This is recorded in the source-bound release admission as `OWNER_ACCEPTED_EXPOSURE`, with observation `NOT_TESTED`; no isolation test is represented or required. The actual consequences are direct API control outside Owner/Guest PWA visibility and command constraints, subject to WLED firmware support. Fresh AUX identity/V7 rollback readback, exact package/source, one-attempt admission, durable receipt, and all powered electrical and physical UV checks remain required. The backend, Owner, and Opal UV activation gates remain closed until their existing commissioning criteria pass.

Fresh preflight must identify the exact owner-confirmed V7 baseline, confirm its retained rollback package, and save the pre-install snapshot. Installation does not accept hardware or physical UV readiness. Powered voltage/current/temperature, independent channels, Matrix following, combined load, restoration, and device acceptance remain for the consolidated field session; database and Opal activation gates stay closed until those existing gates pass.

### Existing combined field checks

After the software gate is closed and Cart/Opal are present:

1. Use the retained V7 image as the rollback and record the exact install transaction; the owner-confirmed V7 baseline is not a recovery investigation.
2. Confirm the 5V rail and channel behavior at low output: Cart/RIM only, then Bar/SHORT only; record voltage, current, temperature, channel mapping, and device readback. Confirm underglow still works.
3. Exercise independent caps, shared slider, Follow Matrix with fresh and stale audio, manual levels without Matrix audio, and explicit zero/off. Confirm no unexpected channel activation and restore both strips to off at closeout.
4. Verify Owner gateway authentication and command acknowledgments on its supported routes. Record that direct unauthenticated WLED access remains owner-accepted and outside those routes; do not label it blocked.

Keep the release fail-closed until its named software, network, and device checks pass. Do not repeat the accepted physical-design review or ask for additional owner preparation while Cart and Opal are away.
