# Packet20 fresh live run — complete 28-kernel report

Run: seq21 diagnostic, one boot, 28 kernels once, exact snapshot restore, seq22 Release07 recovery.

Status: PASS — 28/28 kernels, failures=0.

Snapshot: id=1, hash=4177970615; RESTORE_RECEIPT PASS; raw post-restore HBNF reports restoreVerified=true. The exact firmware source assigns restoreVerified from packet20Same(saved, verify).

Device returned to Release07 hbnf-matrix-coordinated-v1-20261002-07 SHA-256 8e8db17786b178fc8fcd2cdf8a21512681ec7158941ee49ea255509970b1bcab.

## Ranking and grouped ranges

Descriptive groups use measured kernel_avg_ms only: >100 ms; 80–100 ms; <=80 ms. They are not acceptance thresholds.

### >100 ms (2)

| Rank | Kernel | Effect ID | Kernel ms avg | Frame ms avg | FPS median | Palette ms avg | Audio ms avg | AUX ms avg | Heap end | RSSI median |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 1 | Parametric_Water | 222 | 167.353 | 205.045 | 4.0 | 26.144 | 2.385 | 0.140 | 128420 | -48.0 |
| 2 | Module_Experiment10 | 247 | 111.331 | 136.139 | 6.0 | 12.125 | 3.626 | 0.147 | 128420 | -48.0 |

### 80–100 ms (6)

| Rank | Kernel | Effect ID | Kernel ms avg | Frame ms avg | FPS median | Palette ms avg | Audio ms avg | AUX ms avg | Heap end | RSSI median |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 3 | Rotating_Blob | 236 | 98.702 | 120.511 | 7.0 | 10.443 | 3.382 | 0.135 | 128420 | -48.0 |
| 4 | SM5 | 246 | 94.552 | 118.728 | 7.0 | 12.040 | 3.526 | 0.139 | 128420 | -48.0 |
| 5 | Water | 228 | 92.157 | 113.694 | 8.0 | 11.913 | 1.213 | 0.135 | 128408 | -48.0 |
| 6 | Big_Caleido | 221 | 85.646 | 107.232 | 8.0 | 11.778 | 1.246 | 0.140 | 128416 | -49.0 |
| 7 | Complex_Kaleido_4 | 226 | 81.724 | 103.396 | 9.0 | 11.905 | 1.283 | 0.135 | 128420 | -48.0 |
| 8 | Complex_Kaleido_3 | 220 | 81.150 | 102.527 | 9.0 | 11.976 | 1.266 | 0.139 | 128428 | -48.0 |

### <=80 ms (20)

| Rank | Kernel | Effect ID | Kernel ms avg | Frame ms avg | FPS median | Palette ms avg | Audio ms avg | AUX ms avg | Heap end | RSSI median |
|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 9 | Complex_Kaleido | 244 | 76.288 | 100.666 | 9.0 | 12.134 | 3.580 | 0.135 | 128420 | -48.0 |
| 10 | Caleido2 | 240 | 75.315 | 99.429 | 9.0 | 12.088 | 3.502 | 0.135 | 128432 | -48.0 |
| 11 | Yves | 241 | 76.034 | 98.794 | 9.0 | 10.848 | 3.405 | 0.133 | 128412 | -48.0 |
| 12 | Caleido3 | 233 | 76.379 | 98.070 | 9.0 | 12.126 | 1.254 | 0.135 | 128404 | -48.0 |
| 13 | Hot_Blob | 232 | 74.757 | 95.036 | 9.0 | 10.602 | 1.123 | 0.131 | 128408 | -48.0 |
| 14 | RGB_Blobs3 | 245 | 70.109 | 93.638 | 10.0 | 11.770 | 3.529 | 0.144 | 128432 | -48.0 |
| 15 | RGB_Blobs5 | 223 | 70.343 | 92.393 | 10.0 | 11.930 | 1.243 | 0.135 | 128408 | -48.0 |
| 16 | RGB_Blobs4 | 229 | 70.138 | 91.889 | 10.0 | 11.773 | 1.238 | 0.144 | 128424 | -48.0 |
| 17 | Polar_Waves | 224 | 67.838 | 89.324 | 10.0 | 12.073 | 1.247 | 0.144 | 128420 | -48.0 |
| 18 | Chasing_Spirals | 235 | 64.482 | 88.198 | 10.0 | 11.832 | 3.477 | 0.131 | 128428 | -48.0 |
| 19 | Lava1 | 239 | 65.207 | 88.046 | 10.0 | 10.879 | 3.454 | 0.133 | 128420 | -48.0 |
| 20 | Spiralus2 | 231 | 65.547 | 87.194 | 10.0 | 12.021 | 1.248 | 0.135 | 127696 | -48.0 |
| 21 | Scaledemo1 | 242 | 57.224 | 80.348 | 11.0 | 11.411 | 3.468 | 0.135 | 128184 | -48.0 |
| 22 | Distance_Experiment | 238 | 56.612 | 79.462 | 11.0 | 11.028 | 3.470 | 0.131 | 128404 | -48.0 |
| 23 | Center_Field | 237 | 55.622 | 78.449 | 12.0 | 11.370 | 3.454 | 0.131 | 128428 | -48.0 |
| 24 | Waves | 234 | 54.055 | 77.425 | 12.0 | 11.531 | 3.522 | 0.137 | 128440 | -48.0 |
| 25 | Complex_Kaleido_6 | 227 | 55.669 | 77.129 | 12.0 | 11.666 | 1.377 | 0.140 | 128420 | -48.0 |
| 26 | Zoom | 243 | 41.600 | 67.216 | 13.0 | 10.947 | 5.861 | 0.131 | 128252 | -48.0 |
| 27 | Complex_Kaleido_5 | 230 | 43.275 | 64.424 | 14.0 | 12.062 | 1.244 | 0.135 | 128420 | -48.0 |
| 28 | Zoom2 | 225 | 40.760 | 62.246 | 15.0 | 12.023 | 1.238 | 0.131 | 128420 | -48.0 |

## Root-cause attribution

Across kernels, median kernel stage is 70.240 ms; palette is 11.869 ms; audio is 2.883 ms; AUX prepare/send is 0.135 ms; unaccounted is 6.857 ms. RSSI remained around −48 dBm. This localizes the dominant cost to effect rendering on Matrix, not transport, audio, AUX, or instrumentation overhead.

The strongest single outlier is Parametric_Water: 167.353 ms kernel stage, 205.045 ms frame, 4 FPS median. Module_Experiment10 is next at 111.331 ms kernel and 136.139 ms frame. Their work occurs in the shared ANIMartRIX render_value() path; Parametric_Water invokes render_value repeatedly per pixel with the same polar angle while computing multiple noise layers. The shared path recomputes sinf/cosf for each layer, although the angle bits are unchanged within a pixel's layer sequence.

Smallest semantics-preserving class-level fix candidate: memoize the immediately previous angle's sin/cos pair in ANIMartRIX render_value(), keyed by the exact IEEE-754 angle bits (including signed zero). This removes duplicate trig calls across same-angle layers without changing the values passed to Perlin noise, palette, or rendering. Treat benefit as unproven until one qualified build and full device performance qualification.

Foundation is NOT qualified. Diagnostic metrics do not supply frame p95/p99/max or heap low-watermark/largest-block; the full soak and feature acceptance gates also remain open. This report proves the dominant timing class and supports a bounded candidate; it is not an acceptance receipt.

## Evidence

- Raw per-kernel JSONL/profile files and complete machine report: `evidence/hbnf-packet20-fresh-20261005/live-sweep/`.
- Ranked CSV: `evidence/hbnf-packet20-fresh-20261005/PACKET20_RANKED_28.csv`.
- Exact restored state and telemetry: `evidence/hbnf-packet20-fresh-20261005/live-sweep/POST_RESTORE_RAW_STATE.json`, `evidence/hbnf-packet20-fresh-20261005/live-sweep/POST_RESTORE_TELEMETRY.json`, `evidence/hbnf-packet20-fresh-20261005/live-sweep/RESTORE_RECEIPT.json`.
- Diagnostic artifact/source binding: `evidence/hbnf-packet20-fresh-20261005/source-artifact-binding.json`; binary ZIP Drive file ID `1VdkleaQttsximOGpYaNMxhnKXsyqsRRK`.
- Release07 seq22 evidence: `evidence/hbnf-packet20-fresh-20261005/release07-seq22/RECOVERY_RESULT.json`; exact BIN SHA `8e8db17786b178fc8fcd2cdf8a21512681ec7158941ee49ea255509970b1bcab`.
